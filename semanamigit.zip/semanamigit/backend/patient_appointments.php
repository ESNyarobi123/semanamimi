<?php
session_start();
require_once 'config.php'; // your DB connection

// Redirect if not logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_login.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];
$patient_name = $_SESSION['patient_name'];

// Fetch appointments for this patient
$stmt = $conn->prepare("
    SELECT a.id, d.name AS doctorName, d.specialization AS doctorSpecialization, 
           a.appointment_date AS appointmentDate, a.time_slot AS appointmentTime, 
           a.reason, a.status
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.id
    WHERE a.patient_id = ?
    ORDER BY a.appointment_date DESC, a.time_slot DESC
");
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
$appointments = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="sw">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SemaNami | My Appointments</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
body { background: #f1f5f9; padding-top: 80px; font-family: system-ui; }
.logo { font-size: 26px; font-weight: 900; }
.logo .sema { color: #dc2626; } .logo .nami { color: #2563eb; }
.navbar-custom { background: #fff; border-bottom: 1px solid #e2e8f0; }
.navbar-custom .nav-link, .navbar-custom .navbar-brand { color: #334155; }
.navbar-custom .nav-link:hover { color: #2563eb; }
.content-wrapper { margin-top: 20px; margin-bottom: 20px; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 6px 15px rgba(0,0,0,0.05); }
.content-wrapper h1 { color: #2563eb; margin-bottom: 1.5rem; }
.table thead { background-color: #2563eb; color: white; }
.table tbody tr:hover { background-color: rgba(37, 99, 235, 0.08); }
.status-badge { padding: 0.35em 0.65em; font-size: .75em; font-weight: 700; border-radius: .375rem; display: inline-block; text-align: center; vertical-align: baseline; }
.status-pending { background-color: #ffc107; color: #000; }
.status-scheduled { background-color: #0d6efd; color: #fff; }
.status-completed { background-color: #198754; color: #fff; }
.status-cancelled { background-color: #6c757d; color: #fff; }
.status-rejected { background-color: #dc3545; color: #fff; }
.status-no_show { background-color: #fd7e14; color: #fff; }
.btn { transition: all 0.2s ease-in-out; }
.btn i { margin-right: 0.4rem; vertical-align: text-bottom; }
.btn-primary { background-color: #2563eb; border: none; }
.btn-primary:hover { background-color: #1e40af; }
.btn-secondary { background-color: #dc2626; color: white; border: none; }
.btn-secondary:hover { background-color: #991b1b; }
.btn-success { background-color: #16a34a; border: none; color: white; }
.btn-success:hover { background-color: #15803d; }
.alert { box-shadow: 0 2px 5px rgba(0,0,0,0.1); display: flex; align-items: center; }
.alert i { margin-right: 0.5rem; font-size: 1.2em; }
.empty-card { text-align: center; padding: 40px; border-radius: 12px; background: #f8fafc; border: 1px dashed #cbd5f5; }
.lang-switch { cursor: pointer; font-weight: 600; font-size: 13px; margin-right: 15px; }
.lang-active { color: #2563eb; }
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
<div class="container-fluid">
    <div class="logo"><span class="sema">Sema</span><span class="nami">Nami</span></div>
    <ul class="navbar-nav ms-auto align-items-center">
        <li class="nav-item me-3">
            <span class="lang-switch lang-active" onclick="setLang('sw')">SW</span> |
            <span class="lang-switch" onclick="setLang('en')">EN</span>
        </li>
        <li class="nav-item">
            <a href="patient_logout.php" class="btn btn-link nav-link">
                <span data-sw="Toka" data-en="Logout">Logout</span> (<?= htmlspecialchars($patient_name) ?>)
            </a>
        </li>
    </ul>
</div>
</nav>

<!-- CONTENT -->
<div class="container content-wrapper">
<h1><i class="bi bi-calendar-check"></i> <span data-sw="Miadi Yangu" data-en="My Appointments">My Appointments</span></h1>
<hr/>

<?php if(empty($appointments)): ?>
    <div class="empty-card">
        <p class="text-muted fs-5" data-sw="Huna miadi yoyote kwa sasa." data-en="You currently have no appointments.">You currently have no appointments.</p>
        <a href="patient_book_appointment.php" class="btn btn-success">
            <i class="bi bi-calendar-plus-fill"></i> <span data-sw="Weka Miadi" data-en="Book an Appointment">Book an Appointment</span>
        </a>
    </div>
<?php else: ?>
<div class="table-responsive">
<table class="table table-striped table-hover align-middle">
<thead>
<tr>
    <th data-sw="Jina la Daktari" data-en="Doctor Name">Doctor Name</th>
    <th data-sw="Maeneo" data-en="Specialization">Specialization</th>
    <th data-sw="Tarehe" data-en="Date">Date</th>
    <th data-sw="Muda" data-en="Time">Time</th>
    <th data-sw="Sababu" data-en="Reason">Reason</th>
    <th data-sw="Hali" data-en="Status">Status</th>
    <th data-sw="Vitendo" data-en="Actions">Actions</th>
</tr>
</thead>
<tbody>
<?php foreach($appointments as $appt): ?>
<tr id="appt-<?= $appt['id'] ?>">
    <td><?= htmlspecialchars($appt['doctorName']) ?></td>
    <td><?= htmlspecialchars($appt['doctorSpecialization']) ?></td>
    <td><?= htmlspecialchars($appt['appointmentDate']) ?></td>
    <td><?= htmlspecialchars($appt['appointmentTime']) ?></td>
    <td><?= htmlspecialchars($appt['reason']) ?></td>
    <td>
        <span class="status-badge status-<?= strtolower($appt['status']) ?>"><?= htmlspecialchars($appt['status']) ?></span>
    </td>
    <td>
    <?php if($appt['status'] == 'PENDING' || $appt['status'] == 'SCHEDULED'): ?>
        <button type="button" class="btn btn-warning btn-sm" onclick="cancelAppointment(<?= $appt['id'] ?>)">
            <i class="bi bi-x-circle-fill"></i> <span data-sw="Ghairi" data-en="Cancel">Cancel</span>
        </button>
    <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php endif; ?>

<div class="mt-4 d-flex justify-content-between">
    <a href="patient_dashboard.php" class="btn btn-secondary">
        <i class="bi bi-arrow-left-circle-fill"></i> <span data-sw="Rudi Dashibodi" data-en="Back to Dashboard">Back to Dashboard</span>
    </a>
    <?php if(!empty($appointments)): ?>
        <a href="patient_book_appointment.php" class="btn btn-success">
            <i class="bi bi-calendar-plus-fill"></i> <span data-sw="Weka Miadi Mwingine" data-en="Book Another Appointment">Book Another Appointment</span>
        </a>
    <?php endif; ?>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function setLang(lang){
    document.querySelectorAll("[data-sw]").forEach(el=>{
        el.textContent = el.getAttribute("data-"+lang);
    });
    document.querySelectorAll(".lang-switch").forEach(el=>{
        el.classList.remove("lang-active");
    });
    document.querySelector("[onclick=\"setLang('"+lang+"')\"]").classList.add("lang-active");
}
setLang('sw');

function cancelAppointment(apptId){
    if(confirm("Una uhakika kuighairi miadi hii?")){
        $.post('cancel_appointment.php', { appointmentId: apptId }, function(resp){
            if(resp.success){
                alert(resp.message);
                $('#appt-'+apptId).remove();
            } else {
                alert(resp.message);
            }
        }, 'json');
    }
}
</script>
</body>
</html>