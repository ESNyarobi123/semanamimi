<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if (!isset($_SESSION['doctor_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit;
}

$doctorId = $_SESSION['doctor_id'];

$input = json_decode(file_get_contents('php://input'), true);
$action = $_GET['action'] ?? null;
$appointmentId = $_GET['id'] ?? null;

if (!$appointmentId || !$action) {
    http_response_code(400);
    echo json_encode(["message" => "Missing parameters"]);
    exit;
}

// Validate appointment belongs to doctor
$stmt = $pdo->prepare("SELECT * FROM appointments WHERE id = ? AND doctor_id = ?");
$stmt->execute([$appointmentId, $doctorId]);
$appointment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$appointment) {
    http_response_code(404);
    echo json_encode(["message" => "Appointment not found"]);
    exit;
}

$statusMap = [
    "approve" => "SCHEDULED",
    "reject" => "REJECTED",
    "cancel" => "CANCELLED",
    "complete" => "COMPLETED"
];

if (!isset($statusMap[$action])) {
    http_response_code(400);
    echo json_encode(["message" => "Invalid action"]);
    exit;
}

// Update appointment
$updateStmt = $pdo->prepare("UPDATE appointments SET status = ?, doctor_notes = ? WHERE id = ?");
$notes = $input['doctorNotes'] ?? null;
$updateStmt->execute([$statusMap[$action], $notes, $appointmentId]);

echo json_encode(["message" => "Appointment $action successfully"]);