<?php
// patient_medications.php
session_start();
require_once 'config.php'; // DB connection

// Check if patient is logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_login.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];
$medications = [];

// Fetch medications for the patient
$stmt = $conn->prepare("
    SELECT m.medication_name, m.dosage, m.frequency, m.duration, m.instructions, m.prescribed_date,
           d.name AS prescribing_doctor_name
    FROM medications m
    LEFT JOIN doctors d ON m.prescribing_doctor_id = d.id
    WHERE m.patient_id = ?
    ORDER BY m.prescribed_date DESC
");
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $medications[] = $row;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="sw">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SemaNami | Dawa Zangu</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
body{background:#f1f5f9;padding-top:80px;font-family:system-ui;}
.logo{font-size:26px;font-weight:900;}
.logo .sema{color:#dc2626;} .logo .nami{color:#2563eb;}
.navbar-custom{background:white;border-bottom:1px solid #e2e8f0;position:relative;}
.navbar-custom .nav-link{color:#334155;} .navbar-custom .nav-link:hover{color:#2563eb;}
.lang-switch{position:absolute;top:12px;right:20px;}
.lang-switch select{border-radius:6px;padding:4px 8px;border:1px solid #cbd5e1;}
.page-card{background:white;border-radius:16px;padding:35px;box-shadow:0 10px 25px rgba(0,0,0,0.05);}
.page-header{display:flex;align-items:center;gap:15px;margin-bottom:25px;}
.page-header i{font-size:35px;color:#2563eb;}
.stat-card{background:white;padding:20px;border-radius:12px;text-align:center;box-shadow:0 6px 15px rgba(0,0,0,0.05);}
.stat-card i{font-size:28px;color:#2563eb;}
.stat-card h5{margin-top:10px;font-weight:700;}
thead.table-theme{background:#2563eb;color:white;}
.table tbody tr:hover{background:#f1f5f9;}
.badge-med{background:#16a34a;}
.badge-warning{background:#f59e0b;}
.empty-card{text-align:center;padding:40px;border-radius:12px;background:#f8fafc;border:1px dashed #cbd5f5;}
.btn-primary{background:#2563eb;border:none;}
.btn-primary:hover{background:#1e40af;}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container-fluid">
    <div class="logo"><span class="sema">Sema</span><span class="nami">Nami</span></div>
    <div class="lang-switch">
      <select id="languageSelect">
        <option value="sw" selected>Swahili</option>
        <option value="en">English</option>
      </select>
    </div>
    <ul class="navbar-nav ms-auto">
      <li class="nav-item">
        <a href="logout.php" class="btn btn-link nav-link">Toka (<?= htmlspecialchars($_SESSION['patient_name']) ?>)</a>
      </li>
    </ul>
  </div>
</nav>

<div class="container">
  <div class="page-card mt-4">
    <div class="page-header">
      <i class="bi bi-capsule-pill"></i>
      <div>
        <h3 id="pageTitle">Dawa Zangu</h3>
        <p class="text-muted mb-0" id="pageSubtitle">Angalia dawa zako za sasa na maelekezo ya matibabu</p>
      </div>
    </div>

    <!-- MEDICATION SUMMARY -->
    <div class="row mb-4">
      <div class="col-md-4">
        <div class="stat-card">
          <i class="bi bi-capsule"></i>
          <h5><?= count($medications) ?></h5>
          <p id="totalMeds">Jumla ya Dawa</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="stat-card">
          <i class="bi bi-clock-history"></i>
          <h5><?= count($medications) ? 'Active' : '-' ?></h5>
          <p id="currentTreatment">Matibabu ya Sasa</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="stat-card">
          <i class="bi bi-person-badge"></i>
          <h5><?= count($medications) ? 'Doctor' : '-' ?></h5>
          <p id="doctorLabel">Daktari Aliyepewa</p>
        </div>
      </div>
    </div>

    <?php if(empty($medications)): ?>
    <div class="empty-card">
      <i class="bi bi-capsule-pill display-5 text-muted"></i>
      <h5 id="emptyTitle">Hakuna Dawa Zilizopatikana</h5>
      <p class="text-muted" id="emptyText">Huna dawa yoyote iliyorekodiwa katika mfumo huu.</p>
    </div>
    <?php else: ?>
    <div class="table-responsive">
      <table class="table table-hover align-middle">
        <thead class="table-theme">
          <tr>
            <th id="tblMedication">Dawa</th>
            <th id="tblDosage">Dozi</th>
            <th id="tblFrequency">Mara</th>
            <th id="tblDuration">Muda</th>
            <th id="tblInstructions">Maelekezo</th>
            <th id="tblDate">Tarehe</th>
            <th id="tblDoctor">Daktari</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach($medications as $med): ?>
          <tr>
            <td><strong><?= htmlspecialchars($med['medication_name']) ?></strong></td>
            <td><?= htmlspecialchars($med['dosage']) ?></td>
            <td><?= htmlspecialchars($med['frequency']) ?></td>
            <td><?= htmlspecialchars($med['duration'] ?: '-') ?></td>
            <td><?= htmlspecialchars($med['instructions'] ?: '-') ?></td>
            <td><?= htmlspecialchars($med['prescribed_date']) ?></td>
            <td><span class="badge bg-primary">Dr. <?= htmlspecialchars($med['prescribing_doctor_name']) ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>

    <div class="mt-4 text-end">
      <a href="patient_dashboard.php" class="btn btn-secondary">
        <i class="bi bi-arrow-left-circle"></i> Rudi Kwenye Dashboard
      </a>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const langTexts = {
  en: {
    pageTitle: "My Medications",
    pageSubtitle: "View your current prescriptions and treatment instructions",
    totalMeds: "Total Medications",
    currentTreatment: "Current Treatment",
    doctorLabel: "Prescribing Physician",
    emptyTitle: "No Medications Found",
    emptyText: "You currently have no prescriptions recorded in the system.",
    tblMedication: "Medication",
    tblDosage: "Dosage",
    tblFrequency: "Frequency",
    tblDuration: "Duration",
    tblInstructions: "Instructions",
    tblDate: "Date",
    tblDoctor: "Doctor",
    backBtn: "Back to Dashboard"
  },
  sw: {
    pageTitle: "Dawa Zangu",
    pageSubtitle: "Angalia dawa zako za sasa na maelekezo ya matibabu",
    totalMeds: "Jumla ya Dawa",
    currentTreatment: "Matibabu ya Sasa",
    doctorLabel: "Daktari Aliyepewa",
    emptyTitle: "Hakuna Dawa Zilizopatikana",
    emptyText: "Huna dawa yoyote iliyorekodiwa katika mfumo huu.",
    tblMedication: "Dawa",
    tblDosage: "Dozi",
    tblFrequency: "Mara",
    tblDuration: "Muda",
    tblInstructions: "Maelekezo",
    tblDate: "Tarehe",
    tblDoctor: "Daktari",
    backBtn: "Rudi Kwenye Dashboard"
  }
};

document.getElementById('languageSelect').addEventListener('change', function(){
  const lang = this.value;
  for(const id in langTexts[lang]){
    const el = document.getElementById(id);
    if(el) el.textContent = langTexts[lang][id];
  }
});
</script>

</body>
</html>