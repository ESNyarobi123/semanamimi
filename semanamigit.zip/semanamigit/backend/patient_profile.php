<?php
// patient_profile.php
session_start();
require_once 'config.php'; // your DB connection

// Check if patient is logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_login.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];
$message = '';

// Fetch patient info
$stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
$patient = $result->fetch_assoc();
$stmt->close();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = $_POST['name'];
    $phone = $_POST['personalNumber'];
    $address = $_POST['address'];

    $stmt = $conn->prepare("UPDATE patients SET name=?, phone=?, address=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $phone, $address, $patient_id);
    if ($stmt->execute()) {
        $message = "Profile updated successfully!";
        // refresh patient data
        $patient['name'] = $name;
        $patient['phone'] = $phone;
        $patient['address'] = $address;
    } else {
        $message = "Error updating profile.";
    }
    $stmt->close();
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current = $_POST['currentPassword'];
    $new = $_POST['newPassword'];
    $confirm = $_POST['confirmPassword'];

    if (!password_verify($current, $patient['password'])) {
        $message = "Current password incorrect!";
    } elseif ($new !== $confirm) {
        $message = "New passwords do not match!";
    } else {
        $hashed = password_hash($new, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("UPDATE patients SET password=? WHERE id=?");
        $stmt->bind_param("si", $hashed, $patient_id);
        if ($stmt->execute()) {
            $message = "Password changed successfully!";
        } else {
            $message = "Error changing password!";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="sw">
<head>
<meta charset="UTF-8">
<title>SemaNami | Patient Profile</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
/* Use your existing styling from the HTML you shared */
body{background:#f1f5f9;font-family:system-ui;padding-top:80px;}
.logo{font-size:26px;font-weight:900;}
.logo .sema{color:#dc2626;}
.logo .nami{color:#2563eb;}
.navbar-custom{background:white;border-bottom:1px solid #e2e8f0;}
.navbar-custom .nav-link{color:#334155;font-weight:500;}
.navbar-custom .nav-link:hover{color:#2563eb;}
.lang-switch{cursor:pointer;font-weight:600;font-size:13px;}
.lang-active{color:#2563eb;}
.profile-container{background:linear-gradient(180deg,#ffffff,#f8fafc);border-radius:16px;padding:35px;box-shadow:0 10px 25px rgba(0,0,0,0.05);}
.profile-header{display:flex;align-items:center;gap:20px;margin-bottom:30px;}
.avatar{width:80px;height:80px;border-radius:50%;background:#2563eb;display:flex;align-items:center;justify-content:center;font-size:40px;color:white;}
.stat-card{background:white;padding:20px;border-radius:12px;text-align:center;box-shadow:0 6px 15px rgba(0,0,0,0.05);}
.stat-card i{font-size:30px;color:#2563eb;}
.stat-card h5{margin-top:10px;font-weight:700;}
.action-panel{margin-top:30px;display:flex;gap:10px;flex-wrap:wrap;}
.modal-header{background:#2563eb;color:white;}
.modal-header .btn-close{filter:brightness(0) invert(1);}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
  <div class="container-fluid">
    <div class="logo"><span class="sema">Sema</span><span class="nami">Nami</span></div>
    <ul class="navbar-nav ms-auto align-items-center">
      <li class="me-3">
        <span class="lang-switch lang-active" onclick="setLang('sw')">SW</span> | 
        <span class="lang-switch" onclick="setLang('en')">EN</span>
      </li>
      <li class="nav-item">
        <a href="logout.php" class="btn btn-link nav-link">Toka (<?= htmlspecialchars($patient['name']) ?>)</a>
      </li>
    </ul>
  </div>
</nav>

<div class="container">
  <?php if($message): ?>
  <div class="alert alert-info mt-3"><?= $message ?></div>
  <?php endif; ?>

  <div class="profile-container mt-4">
    <div class="profile-header">
      <div class="avatar"><i class="bi bi-person-fill"></i></div>
      <div>
        <h4><?= htmlspecialchars($patient['name']) ?></h4>
        <p class="text-muted">Patient ID: <?= $patient['id'] ?></p>
      </div>
    </div>

    <!-- QUICK STATS -->
    <div class="row mb-4">
      <div class="col-md-4">
        <div class="stat-card">
          <i class="bi bi-calendar-check"></i>
          <h5>3</h5>
          <p>Miadi</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="stat-card">
          <i class="bi bi-capsule"></i>
          <h5>5</h5>
          <p>Dawa</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="stat-card">
          <i class="bi bi-chat-dots"></i>
          <h5>2</h5>
          <p>Mashauriano</p>
        </div>
      </div>
    </div>

    <!-- INFO SECTIONS -->
    <div class="row">
      <div class="col-md-6">
        <h5>Taarifa Binafsi</h5>
        <ul class="list-group">
          <li class="list-group-item">Umri: <?= $patient['age'] ?></li>
          <li class="list-group-item">Jinsia: <?= $patient['gender'] ?></li>
          <li class="list-group-item">Simu: <?= $patient['phone'] ?></li>
          <li class="list-group-item">Anwani: <?= $patient['address'] ?></li>
        </ul>
      </div>
      <div class="col-md-6">
        <h5>Taarifa za Mlezi</h5>
        <ul class="list-group">
          <li class="list-group-item">Jina: <?= $patient['guardian_name'] ?></li>
          <li class="list-group-item">Uhusiano: <?= $patient['guardian_relation'] ?></li>
          <li class="list-group-item">Simu: <?= $patient['guardian_phone'] ?></li>
        </ul>
      </div>
    </div>

    <!-- ACTION BUTTONS -->
    <div class="action-panel">
      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editProfileModal">
        <i class="bi bi-pencil"></i> Hariri Wasifu
      </button>
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
        <i class="bi bi-key"></i> Badili Nenosiri
      </button>
      <a href="patient_dashboard.php" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Dashboard
      </a>
    </div>
  </div>
</div>

<!-- EDIT PROFILE MODAL -->
<div class="modal fade" id="editProfileModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Hariri Wasifu</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form method="POST">
          <input type="hidden" name="update_profile" value="1">
          <div class="mb-3">
            <label>Jina</label>
            <input class="form-control" name="name" value="<?= htmlspecialchars($patient['name']) ?>">
          </div>
          <div class="mb-3">
            <label>Simu</label>
            <input class="form-control" name="personalNumber" value="<?= htmlspecialchars($patient['phone']) ?>">
          </div>
          <div class="mb-3">
            <label>Anwani</label>
            <input class="form-control" name="address" value="<?= htmlspecialchars($patient['address']) ?>">
          </div>
          <button class="btn btn-primary w-100">Hifadhi</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- CHANGE PASSWORD MODAL -->
<div class="modal fade" id="changePasswordModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Badili Nenosiri</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form method="POST">
          <input type="hidden" name="change_password" value="1">
          <div class="mb-3">
            <label>Nenosiri la Sasa</label>
            <input type="password" class="form-control" name="currentPassword">
          </div>
          <div class="mb-3">
            <label>Nenosiri Jipya</label>
            <input type="password" class="form-control" name="newPassword">
          </div>
          <div class="mb-3">
            <label>Thibitisha Nenosiri</label>
            <input type="password" class="form-control" name="confirmPassword">
          </div>
          <button class="btn btn-success w-100">Badili Nenosiri</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>