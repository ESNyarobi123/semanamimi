<?php
// patient_dashboard.php
session_start();
require_once 'config.php'; // Database connection

// Redirect to login if not logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_login.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];
$patient_name = $_SESSION['patient_name'];

// Fetch patient medications
$stmt = $conn->prepare("
    SELECT m.medication_name, m.dosage, m.frequency, m.duration, m.instructions, m.prescribed_date,
           d.name AS doctor_name
    FROM medications m
    LEFT JOIN doctors d ON m.doctor_id = d.id
    WHERE m.patient_id = ?
    ORDER BY m.prescribed_date DESC
");
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
$medications = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="sw">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SemaNami | Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
body { background: #f1f5f9; padding-top: 80px; font-family: system-ui; }
.logo { font-size: 26px; font-weight: 900; }
.logo .sema { color: #dc2626; } .logo .nami { color: #2563eb; }
.navbar-custom { background: #fff; border-bottom: 1px solid #e2e8f0; }
.navbar-custom .nav-link { color: #334155; }
.navbar-custom .nav-link:hover { color: #dc2626; }
.lang-switcher { cursor: pointer; font-weight: 600; font-size: 13px; margin-right: 15px; }
.lang-active { color: #2563eb; }
.sidebar { min-height: calc(100vh - 80px); background: #fff; padding-top: 20px; border-radius: 12px; box-shadow: 0 6px 15px rgba(0,0,0,0.05); }
.sidebar .nav-link { color: #334155; margin: 5px 10px; border-radius: 8px; padding: 12px; transition: all 0.3s; }
.sidebar .nav-link:hover { background: #2563eb; color: #fff; }
.sidebar .nav-link.active { background: #2563eb; color: #fff; }
.page-card { background: #fff; border-radius: 16px; padding: 30px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); margin-bottom: 30px; }
.page-header { display: flex; align-items: center; gap: 15px; margin-bottom: 25px; }
.page-header i { font-size: 35px; color: #2563eb; }
.stat-card { background: #fff; padding: 20px; border-radius: 12px; text-align: center; box-shadow: 0 6px 15px rgba(0,0,0,0.05); transition: transform 0.2s; }
.stat-card:hover { transform: translateY(-5px); }
.stat-card i { font-size: 28px; color: #2563eb; }
.stat-card h5 { margin-top: 10px; font-weight: 700; }
thead.table-theme { background: #2563eb; color: white; }
.table tbody tr:hover { background: #f1f5f9; }
.badge-med { background: #16a34a; } 
.badge-warning { background: #dc2626; }
.empty-card { text-align: center; padding: 40px; border-radius: 12px; background: #f8fafc; border: 1px dashed #cbd5f5; }
.btn-primary { background: #2563eb; border: none; }
.btn-primary:hover { background: #1e40af; }
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
<div class="container-fluid">
    <div class="logo"><span class="sema">Sema</span><span class="nami">Nami</span></div>
    <ul class="navbar-nav ms-auto align-items-center">
        <li class="nav-item me-3">
            <span class="lang-switch lang-active" onclick="setLang('sw')">SW</span> |
            <span class="lang-switch" onclick="setLang('en')">EN</span>
        </li>
        <li class="nav-item">
            <a href="patient_logout.php" class="btn btn-link nav-link">
                <span data-sw="Toka" data-en="Logout">Logout</span> (<?= htmlspecialchars($patient_name) ?>)
            </a>
        </li>
    </ul>
</div>
</nav>

<div class="container-fluid">
<div class="row">

    <!-- SIDEBAR -->
    <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="patient_dashboard.php">
                    <i class="bi bi-house-door"></i> <span data-sw="Dashibodi" data-en="Dashboard">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="patient_appointments.php">
                    <i class="bi bi-calendar"></i> <span data-sw="Miadi Yangu" data-en="My Appointments">My Appointments</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="patient_book_appointment.php">
                    <i class="bi bi-plus-circle"></i> <span data-sw="Weka Miadi" data-en="Book Appointment">Book Appointment</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="patient_medications.php">
                    <i class="bi bi-capsule-pill"></i> <span data-sw="Dawa Zangu" data-en="My Medications">My Medications</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="patient_profile.php">
                    <i class="bi bi-person"></i> <span data-sw="Profaili Yangu" data-en="My Profile">My Profile</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- MAIN CONTENT -->
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="page-card">

            <!-- HEADER -->
            <div class="page-header">
                <i class="bi bi-speedometer2"></i>
                <div>
                    <h3><span data-sw="Karibu" data-en="Welcome">Welcome</span>, <?= htmlspecialchars($patient_name) ?></h3>
                    <p class="text-muted mb-0" data-sw="Kituo chako cha kati cha miadi na dawa" data-en="Your central hub for appointments and medications">
                        Your central hub for appointments and medications.
                    </p>
                </div>
            </div>

            <!-- STAT CARDS -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="stat-card">
                        <i class="bi bi-capsule"></i>
                        <h5><?= count($medications) ?></h5>
                        <p data-sw="Jumla ya Dawa" data-en="Total Medications">Total Medications</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card">
                        <i class="bi bi-clock-history"></i>
                        <h5 data-sw="Inatumika" data-en="Active">Active</h5>
                        <p data-sw="Matibabu ya Sasa" data-en="Current Treatment">Current Treatment</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card">
                        <i class="bi bi-person-badge"></i>
                        <h5 data-sw="Daktari" data-en="Doctor">Doctor</h5>
                        <p data-sw="Daktari Aliye toa Dawa" data-en="Prescribing Physician">Prescribing Physician</p>
                    </div>
                </div>
            </div>

            <!-- MEDICATION TABLE OR EMPTY -->
            <?php if (empty($medications)): ?>
                <div class="empty-card">
                    <i class="bi bi-capsule-pill display-5 text-muted"></i>
                    <h5 data-sw="Hakuna Dawa Iliyopatikana" data-en="No Medications Found">No Medications Found</h5>
                    <p class="text-muted" data-sw="Huna dawa yoyote iliyoingizwa katika mfumo" data-en="You currently have no prescriptions recorded in the system">
                        You currently have no prescriptions recorded in the system.
                    </p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-theme">
                            <tr>
                                <th data-sw="Dawa" data-en="Medication">Medication</th>
                                <th data-sw="Dozi" data-en="Dosage">Dosage</th>
                                <th data-sw="Mara" data-en="Frequency">Frequency</th>
                                <th data-sw="Muda" data-en="Duration">Duration</th>
                                <th data-sw="Maelekezo" data-en="Instructions">Instructions</th>
                                <th data-sw="Tarehe" data-en="Date">Date</th>
                                <th data-sw="Daktari" data-en="Doctor">Doctor</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($medications as $med): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($med['medication_name']) ?></strong></td>
                                <td><?= htmlspecialchars($med['dosage']) ?></td>
                                <td><?= htmlspecialchars($med['frequency']) ?></td>
                                <td><?= htmlspecialchars($med['duration'] ?: '-') ?></td>
                                <td><?= htmlspecialchars($med['instructions'] ?: '-') ?></td>
                                <td><?= htmlspecialchars($med['prescribed_date']) ?></td>
                                <td><span class="badge badge-med">Dr. <?= htmlspecialchars($med['doctor_name']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

        </div>
    </main>
</div>
</div>

<script>
function setLang(lang){
    document.querySelectorAll("[data-sw]").forEach(el=>{
        el.textContent = el.getAttribute("data-"+lang);
    });
    document.querySelectorAll(".lang-switch").forEach(el=>{
        el.classList.remove("lang-active");
    });
    document.querySelector("[onclick=\"setLang('"+lang+"')\"]").classList.add("lang-active");
}
setLang('sw');
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>