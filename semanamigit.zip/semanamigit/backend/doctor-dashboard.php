<?php
session_start();
require_once 'db.php'; // Your database connection script

// Check if doctor is logged in
if (!isset($_SESSION['doctor_id'])) {
    header("Location: login.php");
    exit;
}

$doctorId = $_SESSION['doctor_id'];

// Fetch doctor info
$stmt = $pdo->prepare("SELECT id, name, email, user_type FROM doctors WHERE id = ?");
$stmt->execute([$doctorId]);
$doctor = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$doctor) {
    die("Doctor not found.");
}

// Pass data to Thymeleaf or just render PHP variables
// Example if you want to use in JS or inline PHP:
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Dashboard</title>
</head>
<body>
    <h1>Welcome, Dr. <?php echo htmlspecialchars($doctor['name']); ?></h1>
    <p>Email: <?php echo htmlspecialchars($doctor['email']); ?></p>
    <p>User Type: <?php echo htmlspecialchars($doctor['user_type']); ?></p>
</body>
</html>