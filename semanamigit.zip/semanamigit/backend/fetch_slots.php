<?php
require 'config.php';
$doctorId = $_GET['doctorId'] ?? '';
$date = $_GET['date'] ?? '';
if(!$doctorId || !$date) exit;

$allSlots = ['09:00','10:00','11:00','12:00','14:00','15:00','16:00'];
$stmt = $conn->prepare("SELECT time_slot FROM appointments WHERE doctor_id=? AND appointment_date=?");
$stmt->bind_param("is",$doctorId,$date);
$stmt->execute();
$booked = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$bookedSlots = array_column($booked,'time_slot');

foreach($allSlots as $slot){
    $disabled = in_array($slot,$bookedSlots) ? 'disabled' : '';
    $btnClass = in_array($slot,$bookedSlots) ? 'btn-secondary' : 'slot-button';
    echo '<button type="button" class="btn '.$btnClass.'" '.$disabled.' data-time="'.$slot.'">'.$slot.'</button>';
}
$stmt->close();