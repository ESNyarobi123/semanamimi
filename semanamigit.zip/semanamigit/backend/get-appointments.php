<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if (!isset($_SESSION['doctor_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit;
}

$doctorId = $_SESSION['doctor_id'];

// Fetch appointments
$stmt = $pdo->prepare("SELECT a.id, p.name AS patientName, a.appointment_datetime, a.reason, a.status 
                       FROM appointments a 
                       JOIN patients p ON a.patient_id = p.id 
                       WHERE a.doctor_id = ? 
                       ORDER BY a.appointment_datetime DESC");
$stmt->execute([$doctorId]);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($appointments);