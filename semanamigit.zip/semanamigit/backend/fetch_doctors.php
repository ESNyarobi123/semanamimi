<?php
require 'config.php';
$spec = $_GET['specialization'] ?? '';
if(!$spec) exit;

$stmt = $conn->prepare("SELECT id, name FROM doctors WHERE specialization=? ORDER BY name ASC");
$stmt->bind_param("s", $spec);
$stmt->execute();
$result = $stmt->get_result();

echo '<option value="" selected disabled>-- Select Doctor --</option>';
while($row = $result->fetch_assoc()){
    echo '<option value="'.$row['id'].'">'.htmlspecialchars($row['name']).'</option>';
}
$stmt->close();