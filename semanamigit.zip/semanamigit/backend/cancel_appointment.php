<?php
session_start();
require 'config.php';
header('Content-Type: application/json');

$patient_id = $_SESSION['patient_id'] ?? 0;
$appointmentId = $_POST['appointmentId'] ?? 0;

if(!$patient_id || !$appointmentId){
    echo json_encode(['success'=>false,'message'=>'Invalid request']);
    exit;
}

// Check if appointment belongs to this patient and is cancellable
$stmt = $conn->prepare("SELECT status FROM appointments WHERE id=? AND patient_id=?");
$stmt->bind_param("ii",$appointmentId,$patient_id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$res){
    echo json_encode(['success'=>false,'message'=>'Appointment not found']);
    exit;
}

if(!in_array($res['status'], ['PENDING','SCHEDULED'])){
    echo json_encode(['success'=>false,'message'=>'Cannot cancel this appointment']);
    exit;
}

// Update status to CANCELLED
$stmt = $conn->prepare("UPDATE appointments SET status='CANCELLED' WHERE id=?");
$stmt->bind_param("i",$appointmentId);
$success = $stmt->execute();
$stmt->close();

echo json_encode(['success'=>$success,'message'=>$success ? 'Appointment cancelled successfully' : 'Failed to cancel appointment']);