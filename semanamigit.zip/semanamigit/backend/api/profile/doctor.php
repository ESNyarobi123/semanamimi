<?php
session_start();
require_once '../db.php'; // Your PDO database connection

header('Content-Type: application/json');

// Make sure doctor is logged in
if (!isset($_SESSION['doctor_id'])) {
    http_response_code(401);
    echo json_encode(['message' => 'Unauthorized']);
    exit;
}

$doctorId = $_SESSION['doctor_id'];

// Handle GET: fetch profile
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->prepare("SELECT id, name, email, age, specialization, qualification, yearsOfExperience, phoneNumber, createdAt FROM doctors WHERE id = ?");
    $stmt->execute([$doctorId]);
    $doctor = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($doctor) {
        echo json_encode($doctor);
    } else {
        http_response_code(404);
        echo json_encode(['message' => 'Doctor profile not found']);
    }
    exit;
}

// Handle PUT: update profile
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $input = json_decode(file_get_contents('php://input'), true);

    // Validate inputs
    $phoneNumber = trim($input['phoneNumber'] ?? '');
    $qualification = trim($input['qualification'] ?? '');
    $yearsOfExperience = intval($input['yearsOfExperience'] ?? 0);

    if (empty($phoneNumber) || empty($qualification) || $yearsOfExperience < 0) {
        http_response_code(400);
        echo json_encode(['message' => 'Invalid input data']);
        exit;
    }

    // Update profile
    $stmt = $pdo->prepare("UPDATE doctors SET phoneNumber = ?, qualification = ?, yearsOfExperience = ? WHERE id = ?");
    $updated = $stmt->execute([$phoneNumber, $qualification, $yearsOfExperience, $doctorId]);

    if ($updated) {
        echo json_encode(['message' => 'Profile updated successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['message' => 'Failed to update profile']);
    }
    exit;
}

// Method not allowed
http_response_code(405);
echo json_encode(['message' => 'Method Not Allowed']);