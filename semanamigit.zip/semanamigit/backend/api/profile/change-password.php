<?php
session_start();
require_once '../db.php'; // Your PDO database connection

header('Content-Type: application/json');

if (!isset($_SESSION['doctor_id'])) {
    http_response_code(401);
    echo json_encode(['message' => 'Unauthorized']);
    exit;
}

$doctorId = $_SESSION['doctor_id'];

if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $input = json_decode(file_get_contents('php://input'), true);

    $currentPassword = $input['currentPassword'] ?? '';
    $newPassword = $input['newPassword'] ?? '';
    $confirmPassword = $input['confirmNewPassword'] ?? '';

    if (empty($currentPassword) || empty($newPassword) || $newPassword !== $confirmPassword) {
        http_response_code(400);
        echo json_encode(['message' => 'Invalid password input']);
        exit;
    }

    // Fetch current password hash
    $stmt = $pdo->prepare("SELECT password FROM doctors WHERE id = ?");
    $stmt->execute([$doctorId]);
    $doctor = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$doctor || !password_verify($currentPassword, $doctor['password'])) {
        http_response_code(400);
        echo json_encode(['message' => 'Current password is incorrect']);
        exit;
    }

    // Hash new password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("UPDATE doctors SET password = ? WHERE id = ?");
    $updated = $stmt->execute([$hashedPassword, $doctorId]);

    if ($updated) {
        echo json_encode(['message' => 'Password changed successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['message' => 'Failed to change password']);
    }
    exit;
}

// Method not allowed
http_response_code(405);
echo json_encode(['message' => 'Method Not Allowed']);