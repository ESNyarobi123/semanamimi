<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if (!isset($_SESSION['doctor_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit;
}

$doctorId = $_SESSION['doctor_id'];
$appointmentId = $_GET['id'] ?? null;
$medications = json_decode(file_get_contents('php://input'), true);

if (!$appointmentId || !$medications) {
    http_response_code(400);
    echo json_encode(["message" => "Missing appointment ID or medications"]);
    exit;
}

// Check appointment belongs to doctor
$stmt = $pdo->prepare("SELECT * FROM appointments WHERE id = ? AND doctor_id = ?");
$stmt->execute([$appointmentId, $doctorId]);
$appointment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$appointment) {
    http_response_code(404);
    echo json_encode(["message" => "Appointment not found"]);
    exit;
}

// Insert medications
$pdo->beginTransaction();
try {
    $deleteStmt = $pdo->prepare("DELETE FROM medications WHERE appointment_id = ?");
    $deleteStmt->execute([$appointmentId]);

    $insertStmt = $pdo->prepare("INSERT INTO medications (appointment_id, medication_name, dosage, frequency, duration, instructions) VALUES (?, ?, ?, ?, ?, ?)");

    foreach ($medications as $med) {
        $insertStmt->execute([
            $appointmentId,
            $med['medicationName'],
            $med['dosage'],
            $med['frequency'],
            $med['duration'] ?? null,
            $med['instructions'] ?? null
        ]);
    }
    $pdo->commit();
    echo json_encode(["message" => "Medications saved successfully"]);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(["message" => "Failed to save medications", "error" => $e->getMessage()]);
}