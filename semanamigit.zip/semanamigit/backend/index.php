<?php
// frontend/index.php
session_start();
require '../backend/db.php';

// Fetch verified staff dynamically
$staff_stmt = $pdo->query("SELECT id, name, specialization, experience_years FROM doctors WHERE verified = 1 LIMIT 6");
$verified_staff = $staff_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="sw">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sema Nami - Comprehensive Digital Hospital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .glass-effect { background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(10px); }
        @keyframes pulse-red { 0% { transform: scale(1); } 50% { transform: scale(1.05); } 100% { transform: scale(1); } }
        .emergency-btn { animation: pulse-red 2s infinite; }
    </style>
</head>
<body class="bg-slate-50 font-sans text-slate-800">

<!-- Top bar -->
<div class="bg-indigo-950 text-white text-[10px] py-1.5 px-4 flex justify-between items-center">
    <div class="flex space-x-4">
        <span><i class="fas fa-satellite-dish mr-1 text-green-400"></i> GPS: Active (Kurasini)</span>
        <span><i class="fas fa-lock mr-1 text-blue-300"></i> End-to-End Encrypted</span>
    </div>
    <div class="flex space-x-3">
        <a href="#" id="register-link" class="hover:text-pink-400">Register</a>
        <span class="text-slate-500">|</span>
        <a href="#" id="login-link" class="hover:text-pink-400 font-bold italic">Login <i class="fas fa-sign-in-alt ml-1"></i></a>
    </div>
</div>

<!-- Navigation -->
<nav class="bg-white shadow-sm border-b sticky top-0 z-50 p-4">
    <div class="max-w-7xl mx-auto flex justify-between items-center">
        <div class="flex items-center space-x-3">
            <h1 class="text-2xl font-black text-pink-600 tracking-tighter">Sema<span class="text-indigo-600">Nami</span></h1>
            <span class="hidden md:block text-[10px] bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full font-bold">VIRTUAL HOSPITAL v2.0</span>
        </div>
        <div class="flex items-center space-x-4">
            <button id="emergency-btn" class="emergency-btn bg-red-600 text-white text-xs md:text-sm px-5 py-2.5 rounded-full font-bold shadow-lg flex items-center">
                <i class="fas fa-phone-alt mr-2"></i> SOS EMERGENCY
            </button>
            <div class="h-10 w-10 bg-slate-200 rounded-full border-2 border-indigo-500 flex items-center justify-center cursor-pointer overflow-hidden">
                <i class="fas fa-user text-slate-500"></i> 
            </div>
        </div>
    </div>
</nav>

<main class="max-w-7xl mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">

    <!-- Sidebar -->
    <aside class="lg:col-span-3 space-y-6">
        <!-- Account Card -->
        <div class="bg-white rounded-3xl p-5 shadow-sm border border-slate-200">
            <div class="text-center mb-4">
                <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">Akaunti Yako</p>
            </div>
            <div class="space-y-2">
                <button id="login-btn" class="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-md hover:bg-indigo-700 transition">Ingia (Login)</button>
                <button id="register-btn" class="w-full py-3 bg-white text-indigo-600 border border-indigo-100 rounded-xl font-bold text-sm hover:bg-indigo-50 transition">Jiunge (Register)</button>
            </div>
        </div>

        <!-- Special Services -->
        <div class="bg-white rounded-3xl p-5 shadow-sm border border-slate-200">
            <h3 class="text-xs font-bold text-slate-400 mb-4 uppercase">Huduma Maalum</h3>
            <nav class="space-y-2 text-sm">
                <a href="#" class="flex items-center p-3 rounded-xl hover:bg-pink-50 text-slate-600 hover:text-pink-600 transition">
                    <i class="fas fa-child mr-3"></i> Vijana (Miaka 9-25)
                </a>
                <a href="#" class="flex items-center p-3 rounded-xl hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 transition border-l-4 border-transparent hover:border-indigo-600">
                    <i class="fas fa-stethoscope mr-3"></i> Ushauri wa Daktari
                </a>
                <a href="#" class="flex items-center p-3 rounded-xl hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 transition">
                    <i class="fas fa-video mr-3"></i> Tiba ya Video (Remote)
                </a>
            </nav>
        </div>
    </aside>

    <!-- Main content -->
    <div class="lg:col-span-9 space-y-6">

        <!-- Services Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="bg-red-500 p-5 rounded-3xl text-white shadow-xl relative overflow-hidden group">
                <i class="fas fa-ambulance absolute -right-4 -bottom-4 text-8xl opacity-20 group-hover:scale-110 transition"></i>
                <h4 class="font-bold mb-1 italic">Ambulance</h4>
                <p class="text-[10px] mb-4">Omba usafiri wa dharura sasa hivi.</p>
                <button class="bg-white text-red-600 text-[10px] px-4 py-2 rounded-lg font-black uppercase">Chukua Usafiri</button>
            </div>
            <div class="bg-indigo-600 p-5 rounded-3xl text-white shadow-xl relative overflow-hidden group">
                <i class="fas fa-video-camera absolute -right-4 -bottom-4 text-8xl opacity-20 group-hover:scale-110 transition"></i>
                <h4 class="font-bold mb-1 italic">Video Help</h4>
                <p class="text-[10px] mb-4">Ongea na daktari mubashara ukiwa nyumbani.</p>
                <button class="bg-white text-indigo-600 text-[10px] px-4 py-2 rounded-lg font-black uppercase">Anza Simu</button>
            </div>
            <div class="bg-green-600 p-5 rounded-3xl text-white shadow-xl relative overflow-hidden group">
                <i class="fas fa-user-md absolute -right-4 -bottom-4 text-8xl opacity-20 group-hover:scale-110 transition"></i>
                <h4 class="font-bold mb-1 italic">Vituo vya Karibu</h4>
                <p class="text-[10px] mb-4">Pata mapendekezo ya hospitali bora.</p>
                <button class="bg-white text-green-600 text-[10px] px-4 py-2 rounded-lg font-black uppercase">Tafuta Hospitali</button>
            </div>
        </div>

        <!-- Verified Staff -->
        <section class="bg-white p-6 rounded-3xl border shadow-sm">
            <div class="flex justify-between items-center mb-6">
                <h3 class="font-bold text-slate-800 flex items-center">
                    <i class="fas fa-award text-yellow-500 mr-2"></i> Wakunga Wenye Uzoefu (Verified)
                </h3>
                <a href="#" class="text-indigo-600 text-xs font-bold">Tazama Wote</a>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php foreach($verified_staff as $doc): ?>
                <div class="border rounded-2xl p-4 flex items-center space-x-3 hover:border-indigo-400 transition cursor-pointer">
                    <div class="w-12 h-12 rounded-full bg-slate-100 border-2 border-green-400"></div>
                    <div>
                        <p class="text-sm font-bold"><?= htmlspecialchars($doc['name']) ?></p>
                        <p class="text-[10px] text-slate-500 italic text-green-600 font-bold"><?= htmlspecialchars($doc['experience_years']) ?>+ Miaka Uzoefu</p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>

    </div>
</main>

<!-- Footer -->
<footer class="bg-slate-900 text-slate-400 mt-12 py-12 px-6">
    <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
        <div class="space-y-4">
            <h1 class="text-xl font-bold text-white">Sema<span class="text-pink-500">Nami</span></h1>
            <p class="text-[10px] leading-relaxed">
                SemaNami ni mfumo wa kisasa unaounganisha wagonjwa, madaktari, na wakunga nchini Tanzania kwa kutumia teknolojia ya Blockchain na GPS kuhakikisha huduma bora na za haraka.
            </p>
        </div>
    </div>
</footer>

<!-- Scripts -->
<script>
// SOS Emergency
document.getElementById('emergency-btn').addEventListener('click', () => {
    fetch('../backend/emergency.php', { method:'POST', credentials:'same-origin' })
    .then(res=>res.json())
    .then(data=>alert(data.message));
});

// Login/Register Buttons
['login-btn','register-btn','login-link','register-link'].forEach(id=>{
    document.getElementById(id).addEventListener('click', ()=>alert('Form popup or redirect goes here.'));
});
</script>

</body>
</html>