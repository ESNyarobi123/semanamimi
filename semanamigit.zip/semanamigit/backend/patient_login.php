<?php
// patient_login.php
session_start();
require_once 'config.php'; // Your database connection

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($email) && !empty($password)) {
        // Fetch patient from DB
        $stmt = $conn->prepare("SELECT id, name, email, password_hash FROM patients WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $patient = $result->fetch_assoc();
            // Verify password
            if (password_verify($password, $patient['password_hash'])) {
                // Login successful
                $_SESSION['patient_id'] = $patient['id'];
                $_SESSION['patient_name'] = $patient['name'];
                header("Location: patient_medications.php");
                exit;
            } else {
                $error = "Barua pepe au nenosiri si sahihi"; // Invalid credentials
            }
        } else {
            $error = "Barua pepe au nenosiri si sahihi"; // Invalid credentials
        }
        $stmt->close();
    } else {
        $error = "Tafadhali jaza barua pepe na nenosiri"; // Fill in all fields
    }
}
?>

<!DOCTYPE html>
<html lang="sw">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SemaNami | Patient Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
/* Same styles as your HTML version */
html, body {margin:0; font-family:'Poppins',sans-serif; background:#f1f5f9; min-height:100%;}
body{display:flex; justify-content:center; align-items:center; padding:5px; box-sizing:border-box;}
.login-card{background:white;padding:1.8rem 1.5rem;border-radius:16px; box-shadow:0 12px 25px rgba(0,0,0,0.08); width:100%; max-width:380px; min-width:260px; position:relative;}
.lang-switcher{position:absolute;top:8px;right:12px;font-size:12px;font-weight:600;}
.lang-switch{cursor:pointer;padding:2px 5px;} .lang-active{color:#2563eb;}
.logo{font-size:26px;font-weight:900;text-align:center;margin-bottom:10px;}
.logo .sema{color:#dc2626;} .logo .nami{color:#2563eb;}
.card-header{text-align:center;font-weight:700;font-size:1.3rem;color:#2563eb;margin-bottom:15px;}
.form-control{border-radius:10px;padding:8px;font-size:14px;}
.form-label{font-weight:500;}
.btn-login{background:#2563eb;color:white;font-weight:600;border-radius:10px;font-size:0.95rem;transition:all 0.2s;}
.btn-login:hover{background:#1e40af;box-shadow:0 3px 10px rgba(37,99,235,0.3);}
.alert{display:flex;align-items:center;gap:8px;border-radius:12px;font-size:0.85rem;margin-bottom:10px;}
.alert i{font-size:16px;}
.login-links{text-align:center;margin-top:10px;font-size:0.85rem;}
.login-links a{color:#2563eb;text-decoration:none;}
.login-links a:hover{text-decoration:underline;}
@media (max-width:420px){.login-card{padding:1.3rem 1rem;} .card-header{font-size:1.2rem;} .login-links{font-size:0.8rem;}}
</style>
</head>

<body>

<div class="login-card">
    <div class="lang-switcher">
        <span class="lang-switch lang-active" onclick="setLang('sw')">SW</span> | 
        <span class="lang-switch" onclick="setLang('en')">EN</span>
    </div>
    <div class="logo">
        <span class="sema">Sema</span><span class="nami">Nami</span>
    </div>
    <div class="card-header" data-sw="Ingia Mgonjwa" data-en="Patient Login">Patient Login</div>

    <?php if($error): ?>
    <div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-2">
            <label for="username" class="form-label" data-sw="Barua pepe" data-en="Email">Email</label>
            <input type="email" class="form-control" id="username" name="username" required
                data-placeholder-sw="Andika barua pepe" data-placeholder-en="Enter email" placeholder="Andika barua pepe">
        </div>
        <div class="mb-2">
            <label for="password" class="form-label" data-sw="Nenosiri" data-en="Password">Password</label>
            <input type="password" class="form-control" id="password" name="password" required
                data-placeholder-sw="Andika nenosiri" data-placeholder-en="Enter password" placeholder="Andika nenosiri">
        </div>
        <div class="d-grid mt-2">
            <button type="submit" class="btn btn-login" data-sw="Ingia" data-en="Login">Login</button>
        </div>
    </form>

    <div class="login-links">
        <p><span data-sw="Huna akaunti?" data-en="Don't have an account?">Don't have an account?</span>
        <a href="patient_register.php" data-sw="Jisajili hapa" data-en="Register here">Register here</a></p>
        <p><span data-sw="Wewe ni Daktari?" data-en="Are you a Doctor?">Are you a Doctor?</span>
        <a href="doctor_login.php" data-sw="Ingia hapa" data-en="Login here">Login here</a></p>
    </div>
</div>

<script>
setLang('sw');
function setLang(lang){
    document.querySelectorAll("[data-sw]").forEach(el=>{
        el.textContent = el.getAttribute("data-"+lang)
    });
    document.querySelectorAll("[data-placeholder-sw]").forEach(el=>{
        el.placeholder = el.getAttribute("data-placeholder-"+lang)
    });
    document.querySelectorAll(".lang-switch").forEach(el=>el.classList.remove("lang-active"))
    document.querySelector(`[onclick="setLang('${lang}')"]`).classList.add("lang-active")
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>