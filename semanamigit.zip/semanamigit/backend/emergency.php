<?php
// backend/emergency.php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success'=>false,'message'=>'You must be logged in']);
    exit;
}

$patient_id = $_SESSION['user_id'];
$reason = 'Emergency SOS';

$stmt = $pdo->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, time_slot, reason, status) VALUES (?, NULL, CURDATE(), CURTIME(), ?, 'PENDING')");
if ($stmt->execute([$patient_id, $reason])) {
    echo json_encode(['success'=>true,'message'=>'Emergency request sent']);
} else {
    echo json_encode(['success'=>false,'message'=>'Failed to send request']);
}
?>