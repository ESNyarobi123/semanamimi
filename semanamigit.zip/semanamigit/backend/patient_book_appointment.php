<?php
session_start();
require_once 'config.php'; // Database connection

// Redirect if not logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_login.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];
$patient_name = $_SESSION['patient_name'];

// Fetch all specializations (assuming doctors table has specialization column)
$specializations = $conn->query("SELECT DISTINCT specialization FROM doctors ORDER BY specialization ASC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="sw">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SemaNami | Book Appointment</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
/* Reuse your previous styles */
body { background: #f1f5f9; padding-top: 80px; font-family: system-ui; }
.logo { font-size: 26px; font-weight: 900; }
.logo .sema { color: #dc2626; } .logo .nami { color: #2563eb; }
/* ... rest of your CSS here ... */
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
<div class="container-fluid">
    <div class="logo"><span class="sema">Sema</span><span class="nami">Nami</span></div>
    <ul class="navbar-nav ms-auto align-items-center">
        <li class="nav-item me-3">
            <span class="lang-switch lang-active" onclick="setLang('sw')">SW</span> |
            <span class="lang-switch" onclick="setLang('en')">EN</span>
        </li>
        <li class="nav-item">
            <a href="patient_logout.php" class="btn btn-link nav-link">
                <span data-sw="Toka" data-en="Logout">Logout</span> (<?= htmlspecialchars($patient_name) ?>)
            </a>
        </li>
    </ul>
</div>
</nav>

<!-- CONTENT -->
<div class="container content-wrapper">
    <h2><i class="bi bi-calendar-plus"></i> <span data-sw="Weka Miadi Mpya" data-en="Book a New Appointment">Book a New Appointment</span></h2>
    <hr/>
    <div id="bookingMessage" class="alert d-none" role="alert"></div>

    <form id="bookingForm">
        <!-- Specialization -->
        <div class="mb-3">
            <label for="specialization" class="form-label" data-sw="Chagua Maeneo ya Madaktari" data-en="Select Specialization:">Select Specialization:</label>
            <select class="form-select" id="specialization" name="specialization" required>
                <option value="" selected disabled>-- Choose Specialization --</option>
                <?php foreach($specializations as $spec): ?>
                    <option value="<?= htmlspecialchars($spec['specialization']) ?>"><?= htmlspecialchars($spec['specialization']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Doctor -->
        <div class="mb-3">
            <label for="doctor" class="form-label" data-sw="Chagua Daktari" data-en="Select Doctor:">Select Doctor:</label>
            <select class="form-select" id="doctor" name="doctorId" required disabled>
                <option value="" selected disabled>-- Select Specialization First --</option>
            </select>
        </div>

        <!-- Date -->
        <div class="mb-3">
            <label for="appointmentDate" class="form-label" data-sw="Chagua Tarehe" data-en="Select Date:">Select Date:</label>
            <input type="date" class="form-control" id="appointmentDate" name="appointmentDate" required disabled/>
        </div>

        <!-- Slots -->
        <div class="mb-3">
            <label class="form-label" data-sw="Muda Unaopatikana" data-en="Available Slots:">Available Slots:</label>
            <div id="slotsContainer">
                <p id="slotsPlaceholder" class="text-muted">Please select a doctor and date first.</p>
            </div>
            <input type="hidden" id="selectedSlotTime" name="selectedSlotTime" />
        </div>

        <!-- Reason -->
        <div class="mb-3">
            <label for="reason" class="form-label" data-sw="Sababu ya Ziara (Hiari)" data-en="Reason for Visit (Optional):">Reason for Visit (Optional):</label>
            <textarea class="form-control" id="reason" name="reason" rows="3"></textarea>
        </div>

        <!-- Buttons -->
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-end mt-4">
            <a href="patient_dashboard.php" class="btn btn-secondary order-sm-1">
                <i class="bi bi-arrow-left-circle-fill"></i> Back to Dashboard
            </a>
            <button type="button" id="bookBtn" class="btn btn-primary order-sm-2" disabled>
                <i class="bi bi-check-circle-fill"></i> Book Appointment
            </button>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
// LANGUAGE SWITCH
function setLang(lang){
    document.querySelectorAll("[data-sw]").forEach(el=>{
        el.textContent = el.getAttribute("data-"+lang);
    });
    document.querySelectorAll(".lang-switch").forEach(el=>{
        el.classList.remove("lang-active");
    });
    document.querySelector("[onclick=\"setLang('"+lang+"')\"]").classList.add("lang-active");
}
setLang('sw');

// LOAD DOCTORS BASED ON SPECIALIZATION
$('#specialization').change(function(){
    var spec = $(this).val();
    $('#doctor').prop('disabled', true).html('<option>Loading...</option>');
    $.get('fetch_doctors.php', { specialization: spec }, function(data){
        $('#doctor').prop('disabled', false).html(data);
        $('#appointmentDate').prop('disabled', true).val('');
        $('#slotsContainer').html('<p class="text-muted">Please select a doctor and date first.</p>');
        $('#bookBtn').prop('disabled', true);
    });
});

// ENABLE DATE AFTER DOCTOR SELECTED
$('#doctor').change(function(){
    $('#appointmentDate').prop('disabled', false).val('');
    $('#slotsContainer').html('<p class="text-muted">Please select a date first.</p>');
    $('#bookBtn').prop('disabled', true);
});

// LOAD AVAILABLE SLOTS BASED ON DATE
$('#appointmentDate').change(function(){
    var doctorId = $('#doctor').val();
    var date = $(this).val();
    $('#slotsContainer').html('Loading slots...');
    $.get('fetch_slots.php', { doctorId: doctorId, date: date }, function(data){
        $('#slotsContainer').html(data);
        $('#bookBtn').prop('disabled', false);
    });
});

// SLOT SELECTION
$(document).on('click', '.slot-button', function(){
    $('.slot-button').removeClass('selected-slot');
    $(this).addClass('selected-slot');
    $('#selectedSlotTime').val($(this).data('time'));
});

// BOOK APPOINTMENT
$('#bookBtn').click(function(){
    if(!$('#selectedSlotTime').val()){
        alert('Please select a time slot.');
        return;
    }
    $.post('book_appointment_process.php', $('#bookingForm').serialize(), function(resp){
        $('#bookingMessage').removeClass('d-none').text(resp.message).addClass(resp.success ? 'alert-success' : 'alert-danger');
        if(resp.success) $('#bookingForm')[0].reset();
    }, 'json');
});
</script>
</body>
</html>